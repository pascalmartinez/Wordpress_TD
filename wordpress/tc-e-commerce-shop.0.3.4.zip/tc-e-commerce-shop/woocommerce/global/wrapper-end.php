<?php
/**
 * Content wrappers - end
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
	</div>
</section>
